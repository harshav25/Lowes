//
//  MovieTableCell.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import UIKit

class MovieTableCell: UITableViewCell {

    static var identifier = "MovieTableCell"
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!


    override func awakeFromNib() {
        super.awakeFromNib()
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        // Initialization code
        
    }

    func configureCell(movie:Movie)  {
        titleLabel.text = movie.title ?? ""
        dateLabel.text = (movie.releaseDate ?? "").movieReleaseDateFormat
        ratingLabel.text = ""
        if let rating = movie.voteAverage {
            ratingLabel.text = "\(rating)"
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
