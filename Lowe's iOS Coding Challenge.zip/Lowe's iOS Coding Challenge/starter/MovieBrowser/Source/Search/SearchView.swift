//
//  SearchView.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import UIKit
import Foundation

protocol MovieSearchProtocal {
    func didSelectGoSearch(_ searchQuery:String)
}

class SearchView: UIView {

    public var searchBar = UISearchBar()
    public var goButton = UIButton(type: .custom)
    var delegate:MovieSearchProtocal?
    //var isSearchActive:Bool = false
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUpUI()
    }
    
    func setUpUI() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = .white
        
        self.addSubview(searchBar)
        let width = (self.frame.size.width - 70)
        searchBar.frame = CGRect(x: 10, y: 10, width: width, height: 40)
        searchBar.backgroundImage = UIImage()
        searchBar.placeholder = StringConstants.SearchBarPlaceHolder
        searchBar.searchTextField.clearButtonMode = .whileEditing
        
        self.addSubview(goButton)
        goButton.setTitle(StringConstants.GoButtonTitle, for: .normal)
        goButton.setTitleColor(UIColor(red: (52.0/255.0), green: (120.0/255.0), blue: (246.0/255.0), alpha: 1), for: .normal)
        goButton.addTarget(self, action: #selector(goButtonTapped), for: .touchUpInside)
        goButton.frame = CGRect(x: width + 10, y: 10, width: 50, height: 40)
        
        self.setNeedsLayout()
        
    }
    @objc func goButtonTapped() {
        if let searchbarText = searchBar.text, searchbarText != "" {
            delegate?.didSelectGoSearch(searchbarText)
        }
        
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
    }
    
}
/*
extension SearchView: UISearchBarDelegate {

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearchActive = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSearchActive = false
    }
}*/
