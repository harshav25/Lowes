//
//  SearchViewController.swift
//  SampleApp
//
//  Created by Struzinski, Mark on 2/19/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import UIKit
import Foundation

class SearchViewController: UIViewController {
    
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var noResultsLabel: UILabel!
    @IBOutlet weak var movieTableView: UITableView!
    var viewModel = MoviesViewModel()
    var searchView = SearchView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 60))
    var isServiceCallinProgress = false
    var query = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = StringConstants.MovieSearchTitle
        movieTableView.dataSource = self
        movieTableView.delegate = self
        movieTableView.tableFooterView = UIView()
        searchView.delegate = self
        self.movieTableView.tableHeaderView = searchView
        movieTableView.estimatedRowHeight = 100
        noResultsLabel.text = StringConstants.NoResults
        noResultsLabel.layer.zPosition = 1
        loadingIndicator.layer.zPosition = 1
        movieTableView.keyboardDismissMode = .onDrag
        loadingIndicator.tintColor = .darkGray
        loadingIndicator.stopAnimating()
        self.navigationController?.navigationBar.tintColor = .blue
        let app = UINavigationBarAppearance()
        app.backgroundColor = UIColor(red: (52.0/255.0), green: (120.0/255.0), blue: (246.0/255.0), alpha: 1)
            self.navigationController?.navigationBar.scrollEdgeAppearance = app
        self.navigationController?.navigationBar.tintColor = .white
    }

    func loadMoviesFromServer(query:String) {
        showIndicator()
        viewModel.retriveItemsFromServer(query:query, completion: {
            self.updateMovierecords()
        })
    }
    func updateMovierecords(){
        DispatchQueue.main.async {
            self.movieTableView.reloadData()
            if self.viewModel.moviesArr.count == 0 {
                self.noResultsLabel.isHidden = false
            }else{
                self.noResultsLabel.isHidden = true
            }
            self.hideIndicator()
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let selectedIndex = movieTableView.indexPathForSelectedRow
        let movie = viewModel.moviesArr[selectedIndex?.row ?? 0]
        if let detailsVC = segue.destination as? MovieDetailViewController
        {
            detailsVC.movieObject = movie
        }
    }
    func showIndicator() {
        self.noResultsLabel.isHidden = true
        loadingIndicator.startAnimating()
        loadingIndicator.isHidden = false
    }
    func hideIndicator() {
        loadingIndicator.stopAnimating()
        loadingIndicator.isHidden = true
        self.view.endEditing(true)
    }
}
extension SearchViewController : MovieSearchProtocal {
    func didSelectGoSearch(_ searchQuery: String) {
        viewModel.moviesArr.removeAll()
        self.query = searchQuery
        self.loadMoviesFromServer(query: searchQuery)
    }
}


extension SearchViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.moviesArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableCell.identifier) as? MovieTableCell {
            cell.configureCell(movie: viewModel.moviesArr[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
}

extension SearchViewController : UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if viewModel.pageIndex == 1 {
            return
        }
        let height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        if distanceFromBottom < height {
            if isServiceCallinProgress == false {
                //showIndicator()
                isServiceCallinProgress = !isServiceCallinProgress
                viewModel.retriveItemsFromServer(query: self.query, pageIndex: viewModel.pageIndex) {
                    self.isServiceCallinProgress = !self.isServiceCallinProgress
                    self.updateMovierecords()
                }
            }
            
        }
    }
}
