//
//  MovieDetailViewController.swift
//  SampleApp
//
//  Created by Struzinski, Mark on 2/26/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import UIKit

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var moviewTitleLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var moviePreviewImage: UIImageView!
    
    var movieObject:Movie?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    func configureUI() {
        moviewTitleLabel.text = movieObject?.title ?? ""
        releaseDateLabel.text = "Release Date: \((movieObject?.releaseDate ?? "").detailsDateFormat)"
        descriptionLabel.text = movieObject?.overview ?? ""
        moviePreviewImage.imageFromServerURL(movieObject?.posterPath ?? "")
        moviePreviewImage.contentMode = .scaleAspectFit
        moviePreviewImage.layer.cornerRadius = 8
    }
    
}
