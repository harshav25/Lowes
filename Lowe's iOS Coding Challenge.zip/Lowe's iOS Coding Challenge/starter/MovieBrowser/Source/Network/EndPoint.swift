//
//  EndPoint.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation
enum HTTPMethod:String {
    case get = "GET"
    case post = "POST"
}

class EndPoint {
    var path:String = ""
    var urlParameters:[String:Any]
    var method: HTTPMethod = HTTPMethod.get

    init(path:String? = "", urlParameters:[String:Any]? = [:], method:HTTPMethod? = .get) {
        self.path = path!
        self.urlParameters = urlParameters!
        self.urlParameters["api_key"] = Network.shared.apiKey
        self.method = method!
    }
    
}
