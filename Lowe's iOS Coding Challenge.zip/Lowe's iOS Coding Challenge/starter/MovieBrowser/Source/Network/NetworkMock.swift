//
//  APIHelperMock.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation

/// Mocking For Test cases
class NetworkMock: ServicesProtocol {
    
    public static var shared = NetworkMock()
    
    private init () {}
    
    func retrieveMovies(endPoint: EndPoint, onCompletion: @escaping (MovieModel?, Error?) -> Void) {
        let jsonData = readJSON("MovieDB")
        do {
            let codableModel = try JSONDecoder().decode(MovieModel.self, from: jsonData)
            onCompletion(codableModel,nil)
        } catch let error {
            onCompletion(nil,error)
        }
    }
}
