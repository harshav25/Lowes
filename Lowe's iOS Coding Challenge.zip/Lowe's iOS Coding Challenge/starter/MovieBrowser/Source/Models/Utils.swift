//
//  Utils.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation

func readJSON(_ fileName:String) -> Data {
    if let path = Bundle.main.path(forResource: fileName, ofType: "json") {
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
            return data
          } catch {
                print("JSON File Error \(fileName)")
          }
    }
    return Data()
}
func isMockEnabled() -> Bool {
    if ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] != nil {
        return true
    }
    return false
}
