//
//  MoviesViewModel.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation

class MoviesViewModel {
    
    var apiHelper:ServicesProtocol = Network.shared
    var moviesArr:[Movie] = [Movie]()
    var movieModel:MovieModel!{
        didSet {
            if let movies = movieModel.results {
                appendMoviesToArray(movies: movies)
            }
        }
    }
    
    convenience init(movieModel:MovieModel) {
        self.init()
        
        setMovieModel(newValue: movieModel)
    }
    func setMovieModel(newValue:MovieModel) {
        self.movieModel = newValue
    }
    func appendMoviesToArray(movies:[Movie]) {
        moviesArr.append(contentsOf: movies)
    }
    /* For Pagination */
    var pageIndex:Int {
        if self.moviesArr.count < (movieModel.totalResults ?? 0) {
            return (movieModel.page ?? 1) + 1
        }
        return 1
    }
    
    func retriveItemsFromServer(query:String,pageIndex:Int? = 1, completion: @escaping() -> Void)
    {
        let endPoint = pageIndex == 1 ? EndPoint(urlParameters: ["query":query]) : EndPoint(urlParameters: ["page":pageIndex!,"query":query])
        
        apiHelper.retrieveMovies(endPoint: endPoint) { (model, error) in
            if let movieModel = model {
                self.movieModel = movieModel
                completion()
                DispatchQueue.main.async {
                    //hideIndicator()
                }
            }
        }
    }
}
