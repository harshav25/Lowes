//
//  StringConstants.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation

struct StringConstants {
    static let MovieSearchTitle = "Movie Search"
    static let SearchBarPlaceHolder = "Search by movie name"
    static let GoButtonTitle = "Go"
    static let NoResults = "No results to display.. Search some thing that you are looking for"
}
