//
//  Extensions.swift
//  MovieBrowser
//
//  Created by Harsha Vemula on 11/18/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation
import UIKit

extension String {
    var movieReleaseDateFormat:String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyy-mm-dd"
        let date = formatter.date(from: self)
        
        let displayFormatter = DateFormatter()
        displayFormatter.dateFormat = "MMMM dd, yyyy"
        let displayStr = displayFormatter.string(from: date ?? Date())
        return displayStr
    }
    var detailsDateFormat:String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyy-mm-dd"
        let date = formatter.date(from: self)
        
        let displayFormatter = DateFormatter()
        displayFormatter.dateFormat = "MM/dd/yy"
        let displayStr = displayFormatter.string(from: date ?? Date())
        return displayStr
    }
}
extension UIImageView {

    func imageFromServerURL(_ path: String, placeHolder: UIImage? = UIImage(named: "placeholder")) {
        //self.image = nil
        let URLString = IMAGE_BASE_URL + path
        let imageServerUrl = URLString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        if let url = URL(string: imageServerUrl) {
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                if error != nil {
                    DispatchQueue.main.async {
                        self.image = placeHolder
                    }
                    return
                }
                DispatchQueue.main.async {
                    if let data = data {
                        if let downloadedImage = UIImage(data: data) {
                            self.image = downloadedImage
                        }
                    }
                }
            }).resume()
        }
    }
}
